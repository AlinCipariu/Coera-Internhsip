export class Project{
    id: string;
    name: string;
    teamLeaderId: string;
    createdAt: string;
    changedAt: string;
    deletedAt: string;
    errors: string[];
}