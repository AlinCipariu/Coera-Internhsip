export class Role {
    id: string;
    name: string;
    createdAt: string;
    changedAt: string;
    deletedAt: string;
    errors: string[];
}
