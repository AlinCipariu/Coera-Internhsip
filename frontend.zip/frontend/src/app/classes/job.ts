export class Job{
    id: string;
    name: string;
    cor: string;
    createdAt: string;
    changedAt: string;
    deletedAt: string;
    errors: string[];
}