import { RoleService } from './../../services/role.service';
import { Role } from './../../classes/role';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-find-by-id',
  templateUrl: './role-find-by-id.component.html',
  styleUrls: ['./role-find-by-id.component.css'],
  providers: [
    RoleService
  ]
})
export class RoleFindByIdComponent implements OnInit {
  idToFind: string;
  role: Role;
  status: string;

  constructor(private roleService: RoleService) { }

  ngOnInit() {
  }

  onSearchClick() {
    // alert(JSON.stringify(this.role));
    // add to db
    this.roleService.getRoleById(this.idToFind)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
  }

  checkResponse(response: Role): void {
    this.role = response;
    this.status = "Role was found";
  }

  handleError(error: any) {
    this.status = (JSON.parse(error) as string[]).join(" ");
  }
}
