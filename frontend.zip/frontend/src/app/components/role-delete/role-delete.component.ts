import { RoleService } from './../../services/role.service';
import { Role } from './../../classes/role';
import { Component, OnInit, Input, Output, OnChanges, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-role-delete',
  templateUrl: './role-delete.component.html',
  styleUrls: ['./role-delete.component.css'],
  providers: [
    RoleService
  ]
})
export class RoleDeleteComponent implements OnInit, OnChanges {
  @Input() roleToDelete: Role;

  @Output() refreshRequest = new EventEmitter<void>();

  status: string;

  constructor(private roleService: RoleService) {
  }

  ngOnInit() {
  }

  ngOnChanges() {
    this.status = null;
  }

  onDeleteClick() {
    // alert(JSON.stringify(this.role));
    // add to db
    this.roleService.deleteRole(this.roleToDelete.id)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
  }

  checkResponse(response: Role): void {
    this.roleToDelete = response;
    this.status = "Role succesfully deleted";
    this.refreshRequest.emit();
  }

  handleError(error: any) {
    this.status = (JSON.parse(error) as string[]).join(" ");
  }

  onCancelClick() {
    this.roleToDelete = null;
    this.status = null;
  }

}
