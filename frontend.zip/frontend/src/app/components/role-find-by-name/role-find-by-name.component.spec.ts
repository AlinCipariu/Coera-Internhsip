import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleFindByNameComponent } from './role-find-by-name.component';

describe('RoleFindByNameComponent', () => {
  let component: RoleFindByNameComponent;
  let fixture: ComponentFixture<RoleFindByNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoleFindByNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleFindByNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
