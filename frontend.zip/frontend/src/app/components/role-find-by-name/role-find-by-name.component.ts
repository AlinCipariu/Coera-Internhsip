import { RoleService } from './../../services/role.service';
import { Role } from './../../classes/role';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role-find-by-name',
  templateUrl: './role-find-by-name.component.html',
  styleUrls: ['./role-find-by-name.component.css'],
  providers: [
    RoleService
  ]
})
export class RoleFindByNameComponent implements OnInit {
  nameToFind: string;
  role: Role;
  status: string;

  constructor(private roleService: RoleService) { }

  ngOnInit() {
  }

  onSearchClick() {
    // alert(JSON.stringify(this.role));
    // add to db
    this.roleService.getRoleByName(this.nameToFind)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
  }

  checkResponse(response: Role): void {
    this.role = response;
    this.status = "Role was found";
  }

  handleError(error: any) {
    this.status = (JSON.parse(error) as string[]).join(" ");
  }

}
