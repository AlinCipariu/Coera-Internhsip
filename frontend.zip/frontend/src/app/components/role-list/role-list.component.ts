import { RoleService } from './../../services/role.service';
import { Role } from './../../classes/role';
import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.css'],
  providers: [RoleService]
})
export class RoleListComponent implements OnInit {
  @Output() editRequest = new EventEmitter<Role>();
  @Output() deleteRequest = new EventEmitter<Role>();

  @Input() roles: Role[];
  selectedRole: Role;



  constructor(private roleService: RoleService) { }

  ngOnInit() {    
  }

  onRoleClick(clickedRole: Role) {
    this.selectedRole = clickedRole;
  }

  editClick(roleToEdit: Role) {
    this.editRequest.emit(roleToEdit);
  }

  deleteClick(roleToDelete: Role) {
    this.deleteRequest.emit(roleToDelete);
  }
}
