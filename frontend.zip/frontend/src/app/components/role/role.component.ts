import { Role } from './../../classes/role';
import { RoleService } from './../../services/role.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css'],
  providers: [
    RoleService
  ]
})
export class RoleComponent implements OnInit {
  title: string = "Roles";
  roles: Role[];

  roleToEdit: Role;
  roleToDelete: Role;

  constructor(private roleService: RoleService) { }

  ngOnInit() {
    this.refresh();
  }

  refresh() {
    this.roleService.getRole().then(roles => this.roles = roles);
  }

  requestedEdit(roleToEdit: Role) {
    this.roleToEdit = roleToEdit;
    //
    this.refresh();
  }

  requestedDelete(roleToDelete: Role) {
    this.roleToDelete = roleToDelete;
    //
    this.refresh();
  }

}
