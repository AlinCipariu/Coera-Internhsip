import { RoleService } from './../../services/role.service';
import { Role } from './../../classes/role';
import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';


@Component({
  selector: 'app-role-edit',
  templateUrl: './role-edit.component.html',
  styleUrls: ['./role-edit.component.css'],
  providers: [
    RoleService
  ]
})
export class RoleEditComponent implements OnInit, OnChanges {
  @Input() roleToEdit: Role;

  @Output() refreshRequest = new EventEmitter<void>();

  status: string;

  constructor(private roleService: RoleService) { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.status = null;
  }

  onEditClick() {
    // alert(JSON.stringify(this.role));
    // add to db
    this.roleService.editRole(this.roleToEdit)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
  }

  checkResponse(response: Role): void {
    this.roleToEdit = response;
    this.status = "Role succesfully edited";
    this.refreshRequest.emit();
  }

  handleError(error: any) {
    this.status = (JSON.parse(error) as string[]).join(" ");
  }

  onCancelClick() {
    this.roleToEdit = null;
    this.status = null;
  }

}
