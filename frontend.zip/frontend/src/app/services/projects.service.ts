import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { Project } from '../classes/project'

@Injectable()
export class ProjectsService {

  private projectsUrl = 'http://localhost:59122/api/project';

  constructor(private http: Http) { }


 getProjects(): Promise<Project[]> {
    return this.http.get(this.projectsUrl)
      .toPromise()
      .then(response => response.json() as Project[])
      .catch() // this.handleError
  }

  getProject(projectId: any): Promise<Project> {
    return this.http.get(`${this.projectsUrl}/${projectId}`)
      .toPromise()
      .then(response => response.json() as Project)
      .catch() // this.handleError
  }

  create(project: Project): Observable<Project> {
    let body = JSON.stringify(project);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.projectsUrl, body, options)
      .map(res => res.json().data)
      .catch(this.handleError)

  }

  delete(projectId: string) {
    return this.http.delete(`${this.projectsUrl}/${projectId}`)
      .catch(this.handleError)
  }

  update(project: Project) {
    let body = JSON.stringify(project);
    let headers = new Headers({ 'Content-Type': 'application/json' });

    console.log(body);

    return this.http.put(this.projectsUrl, body, { headers: headers })
      .map(res => res.json())
  }



  private handleError(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }


}
