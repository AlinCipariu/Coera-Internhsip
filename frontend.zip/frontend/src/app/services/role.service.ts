import { Role } from './../classes/role';
import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http'

import 'rxjs/add/operator/toPromise';

@Injectable()
export class RoleService {
  private headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
  private baseURL: string = "http://localhost:59123/api/Roles";

  constructor(private http: Http) { }

  getRole(): Promise<Role[]> {
    return this.http.get(this.baseURL)
      .toPromise()
      .then(response => response.json() as Role[])
      .catch(this.handleError);
  }

  getRoleById(roleId: string): Promise<Role> {
    return this.http.get(`${this.baseURL}/id?id=${roleId}`)
      .toPromise()
      .then(response => response.json() as Role)
      .catch(this.handleError);
  }

  getRoleByName(roleName: string): Promise<Role> {
    return this.http.get(`${this.baseURL}/search/${roleName}`)
      .toPromise()
      .then(response => response.json() as Role)
      .catch(this.handleError);
  }

  createRole(newRole: Role): Promise<Role> {
    return this.http.post(this.baseURL, JSON.stringify(newRole), { headers: this.headers })
      .toPromise()
      .then(resp => resp.json() as Role)
      .catch(this.handleError);
  }

  editRole(editedRole: Role): Promise<Role> {
    return this.http.put(this.baseURL, JSON.stringify(editedRole), { headers: this.headers })
      .toPromise()
      .then(resp => resp.json() as Role)
      .catch(this.handleError);
  }

  deleteRole(roleId: string): Promise<Role> {
    return this.http.delete(`${this.baseURL}?idToDelete=${roleId}`, { headers: this.headers })
      .toPromise()
      .then(resp => resp.json() as Role)
      .catch(this.handleError);
  }

  private handleError(error: Response): Promise<any> {
    switch (error.status) {
      case 404: {
        return Promise.reject(JSON.stringify([error.statusText]));
      }
      default: {
        return Promise.reject(error.text());
      }
    }
  }

}
