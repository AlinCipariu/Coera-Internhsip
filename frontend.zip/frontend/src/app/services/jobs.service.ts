import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import { Job } from '../classes/job'

@Injectable()
export class JobsService {
  private jobsUrl = 'http://localhost:59122/api/job';

  constructor(private http: Http) { }

  getJobs(): Promise<Job[]> {
    return this.http.get(this.jobsUrl)
      .toPromise()
      .then(response => response.json() as Job[])
      .catch() // this.handleError
  }

  getJob(jobId: any): Promise<Job> {
    return this.http.get(`${this.jobsUrl}/${jobId}`)
      .toPromise()
      .then(response => response.json() as Job)
      .catch() // this.handleError
  }

  create(job: Job): Promise<Job> {
    let body = JSON.stringify(job);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    return this.http.post(this.jobsUrl, body, options)
      .toPromise()
      .then(response => response.json() as Job)
      .catch() // this.handleError
  }

  delete(jobId: string) {
    return this.http.delete(`${this.jobsUrl}/${jobId}`)
      .catch(this.handleError)
  }

  update(job: Job) {
    let body = JSON.stringify(job);
    let headers = new Headers({ 'Content-Type': 'application/json' });

    console.log(body);

    return this.http.put(this.jobsUrl, body, { headers: headers })
      .map(res => res.json())
  }

  private handleError(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.message || error);
  }
}