import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { HolidayRequestDTO } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/modules/holiday-request/entity-DTO/HolidayRequestDTO';

@Injectable()
export class HolidayRequestService {
    private hrUrl = 'http://localhost:59122/api/holiday-request';

    constructor(private http: Http) { }

    create(holidayRequest: HolidayRequestDTO): Promise<HolidayRequestDTO> {
        let body = JSON.stringify(holidayRequest);
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });

        return this.http.post(this.hrUrl, body, options)
            .toPromise().
            then(resp => resp.json() as HolidayRequestDTO).
            catch(this.handleError1);
    }
    private handleError1(error: Response): Promise<any> {
        switch (error.status) {
            case 404: {
                return Promise.reject(JSON.stringify([error.statusText]));
            }
            default: {
                return Promise.reject(error.text());
            }
        }
    }

    update(holidayRequest: HolidayRequestDTO) {
        let body = JSON.stringify(holidayRequest);
        let headers = new Headers({ 'Content-Type': 'application/json' });

        return this.http.put(this.hrUrl, body, { headers: headers })
            .toPromise()
            .then(resp => resp.json() as HolidayRequestDTO)
            .catch(this.handleError2);
    }

    private handleError2(error: Response): Promise<any> {
        switch (error.status) {
            case 404: {
                return Promise.reject(JSON.stringify([error.statusText]));
            }
            default: {
                return Promise.reject(error.text());
            }
        }
    }
}

