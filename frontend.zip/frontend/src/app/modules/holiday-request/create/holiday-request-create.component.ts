import { Component, OnInit } from '@angular/core';
import { Router, Params, Route, ActivatedRoute } from '@angular/router';
import { HolidayRequestDTO } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/modules/holiday-request/entity-DTO/HolidayRequestDTO';
import { HolidayRequestService } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/services/holiday-request.service';
import { EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'holiday-request-create',
  templateUrl: './holiday-request-create.component.html',
  styleUrls: ['./holiday-request-create.component.css'],
  providers: [HolidayRequestService]
})
export class HolidayRequestCreateComponent implements OnInit {
  @Output() doneEvent = new EventEmitter<void>();
  holidayRequest: HolidayRequestDTO = new HolidayRequestDTO();
  errors: string[];
  navigated: boolean =false;

  constructor(private router: Router, private holidayRequestService: HolidayRequestService) { }

  ngOnInit() { this.navigated = true; }

  create(): void {
    console.log(this.holidayRequest);
    if (!this.holidayRequest) { return; }
    this.holidayRequestService.create(this.holidayRequest)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
    this.holidayRequest.startDate = new Date();
    this.holidayRequest.endDate = new Date();
    this.holidayRequest.reason = "";

  }

  checkResponse(response: HolidayRequestDTO): void {
    this.doneEvent.emit();
    if (this.navigated) {
      this.navigated = false;
      window.history.back();
    }
  }

  handleError(error: any) {
    this.errors = (JSON.parse(error) as string[]);
    console.log(this.errors);
  }

 
}
