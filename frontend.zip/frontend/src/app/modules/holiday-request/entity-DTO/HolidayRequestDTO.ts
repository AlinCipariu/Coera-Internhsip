import { StatusEnum } from './StatusEnum';
import { HolidayType } from './HolidayTypeDTO';

export class HolidayRequestDTO {
        public id: String;
        public employeeId: String;
        public createdDate: Date;
        public modifiedDate: Date;
        public createdBy: String;
        public elementId: String;
        public startDate: Date;
        public endDate: Date;
        public holidayType: HolidayType;
        public numberOfDays: number;
        public reason: String;
        public response: String;
        public status: StatusEnum;

    constructor() { }
}