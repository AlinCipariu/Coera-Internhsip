export class HolidayType{
    constructor(public name:String,public initial:String){}
}