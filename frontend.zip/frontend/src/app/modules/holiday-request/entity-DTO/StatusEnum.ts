export enum StatusEnum {
    ACCEPTED, PENDING, DECLINED
}