import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HolidayRequestCreateComponent } from './create/holiday-request-create.component';


const routes: Routes = [
  { path: 'create', component: HolidayRequestCreateComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HolidayRequestRoutingModule { }