import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { HolidayRequestRoutingModule } from './holiday-request-routing.module';

import { HolidayRequestCreateComponent } from './create/holiday-request-create.component';
import { CalendarComponent } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/modules/select-and-cancel-holiday-request/select-and-cancel-holiday-request';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        HolidayRequestRoutingModule
        
    ],
    declarations: [
        HolidayRequestCreateComponent, CalendarComponent
    ]
})
export class HolidayRequestModule { }