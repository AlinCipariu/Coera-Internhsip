import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectListComponent } from './list/project-list.component';
import { ProjectEditComponent } from './edit/project-edit.component';
import { ProjectCreateComponent } from './create/project-create.component';

const routes: Routes = [
  { path: 'list', component: ProjectListComponent },
  { path: 'create', component: ProjectCreateComponent },
  { path: 'edit/:id', component: ProjectEditComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectsRoutingModule { }