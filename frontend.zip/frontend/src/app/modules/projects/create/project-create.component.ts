import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { ProjectsService } from '../../../services/projects.service'
import { Project } from './../../../classes/project'
import { Router, Params, Route, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'project-create',
  templateUrl: './project-create.component.html',
  styleUrls: ['./project-create.component.css'],
  providers: [ProjectsService]
})
export class ProjectCreateComponent implements OnInit {
  project: Project = new Project();
  errorMessage: string;

  constructor(private router: Router, private projectService: ProjectsService) { }

  ngOnInit() { }

  addProject(): void {
    if (!this.project) { return; }
    this.projectService.create(this.project)
                       .subscribe(error => this.errorMessage = <any>error);
    this.project.name = "";
    this.project.teamLeaderId = ""; 
  }
}