import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ProjectsService } from '../../../services/projects.service'
import { Project } from './../../../classes/project'
import { Router } from '@angular/router'
import { DatePipe } from '@angular/common';

@Component({
  selector: 'project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css'],
  providers: [ProjectsService]
})
export class ProjectListComponent implements OnInit {
  errorMessage: string;
  _listOfProjects: Project[];
  id: string = "";
  project: Project = new Project();

  @Output() selectedChange: EventEmitter<Project> = new EventEmitter();

  constructor(private router: Router, private projectsService: ProjectsService) { }

  ngOnInit() {
    this.getProjects();
  }

  // Gets the list of projects from service
  getProjects() {
    this.projectsService.getProjects().then(projects => this._listOfProjects = projects);
  }

  deleteProject(id: string) {
    this.projectsService.delete(id).subscribe(
      project => {
        this.getProjects();
      },
      error => this.errorMessage = <any>error,
    );
  }

  goToDetail(project: Project): void {
    let link = ['/projects/edit/', project.id];
    this.router.navigate(link);
  }
}