import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

import { ProjectsService } from '../../../services/projects.service'

import { Project } from './../../../classes/project'

import { Router, Params, Route, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'app-project-edit',
  templateUrl: './project-edit.component.html',
  styleUrls: ['./project-edit.component.css'],
  inputs: ['project']
})
export class ProjectEditComponent implements OnInit {

  @Input() project: Project;
  @Output() close = new EventEmitter();
  errors: string[];
  navigated = false; // true if we navigated here

  id: string;

  projects: Project[]   //                                    TO BE CHANGED WITH EMPLOYEE



  //=======================================================

  employees = [{ id: "1", name: "Ana" }, { id: "2", name: "John" }, { id: "3", name: "Mark" }];

  selectedEmployee = this.employees[1]; // aici defapt fac un get pentru employee cu id declarat mai sus
  onChangeObj(newObj) {
    console.log(newObj.id + " " + newObj.name);
    this.selectedEmployee = newObj;
    // ... do other stuff here ...
  }

  //=======================================================

  constructor(private projectsService: ProjectsService,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.populateDropDown();
    this.route.params.forEach((params: Params) => {

      console.log(params.id); // debug
      this.id = params.id; // debug

      if (params.id !== undefined) {
        let id = params.id;
        this.navigated = true;
        this.projectsService.getProject(params.id) // id
          .then(project => this.project = project);

      } else {
        this.navigated = false;
        this.project.id = params.id;
      }
    })

  }
  //==========================================================================================================================================================
  //                                                 HAS TO BE CHANGED WITH FUTURE EMPLOYEE / ELEMENT SERVICE
  //==========================================================================================================================================================
  populateDropDown() {
    this.projectsService.getProjects().then(projects => this.projects = projects);
  }

  valueChanged(param: any) {
    alert(param)
  }

  save(): void {
    this.projectsService
      .update(this.project)
      .subscribe(project => {
      this.project = project;
        this.goBack(project);
      })
  }

  goBack(savedProject: Project = null): void {
    this.close.emit(savedProject);
    if (this.navigated) {
      window.history.back();
    }
  }
}