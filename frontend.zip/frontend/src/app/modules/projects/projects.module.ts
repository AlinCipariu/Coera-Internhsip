import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ProjectsRoutingModule } from './projects-routing.module';
import { ProjectEditComponent } from './edit/project-edit.component';
import { ProjectListComponent } from './list/project-list.component';
import { ProjectCreateComponent } from './create/project-create.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ProjectsRoutingModule
    ],
    declarations: [
        ProjectEditComponent,
        ProjectListComponent,
        ProjectCreateComponent
    ]
})
export class ProjectsModule { }