import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JobListComponent } from './list/job-list.component';
import { JobCreateComponent } from './create/job-create.component';
import { JobEditComponent } from './edit/job-edit.component';

const routes: Routes = [
  { path: 'list', component: JobListComponent },
  { path: 'create', component: JobCreateComponent },
  { path: 'edit/:id', component: JobEditComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JobsRoutingModule { }