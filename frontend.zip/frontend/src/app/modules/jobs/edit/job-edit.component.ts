import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { Router, Params, Route, ActivatedRoute } from '@angular/router'

import { JobsService } from '../../../services/jobs.service'
import { Job } from './../../../classes/job'

@Component({
  selector: 'job-edit',
  templateUrl: './job-edit.component.html',
  styleUrls: ['./job-edit.component.css'],
  inputs: ['job']
})
export class JobEditComponent implements OnInit {
  @Input() job: Job;
  @Output() close = new EventEmitter();

  errors: string[];
  navigated = false; // true if we navigated here
  id: string;
 
  constructor(
    private jobsService: JobsService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.params.forEach((params: Params) => {
      console.log(params.id); // debug
      this.id = params.id; // debug

      if (params.id !== undefined) {
        let id = params.id;
        this.navigated = true;
        this.jobsService.getJob(params.id).then(job => this.job = job);
      } else {
        this.navigated = false;
        this.job.id = params.id;
      }
    })
  }

  save(): void {
    this.jobsService
        .update(this.job)
        .subscribe(job => { this.job = job;
                            this.goBack(job);})
  }

  goBack(savedJob: Job = null): void {
    this.close.emit(savedJob);
    if (this.navigated) {
      window.history.back();
    }
  }
}