import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { JobsService } from '../../../services/jobs.service'
import { Job } from './../../../classes/job'
import { Router, Params, Route, ActivatedRoute } from '@angular/router'

@Component({
  selector: 'job-create',
  templateUrl: './job-create.component.html',
  styleUrls: ['./job-create.component.css'],
  providers: [JobsService]
})
export class JobCreateComponent implements OnInit {
  @Output() doneEvent = new EventEmitter<void>();
  job: Job = new Job();
  errors: string[];
  navigated = false;

  constructor(private router: Router, private jobsService: JobsService) { }

  ngOnInit() {this.navigated = true;}

  addJob(): void {
    if (!this.job) { return; }
    this.jobsService.create(this.job)
      .then(resp => this.checkResponse(resp))
      .catch(err => this.handleError(err));
    this.job.name = "";
    this.job.cor = "";
  }

   checkResponse(response: Job): void {
    this.doneEvent.emit();
    if (this.navigated) {
      this.navigated = false;
      window.history.back();
    }
  }

  handleError(error: any) {
    this.errors = (JSON.parse(error) as string[]);
   console.log(this.errors);
  }


}