import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { JobsRoutingModule } from './jobs-routing.module';
import { JobListComponent } from './list/job-list.component';
import { JobCreateComponent } from './create/job-create.component';
import { JobEditComponent } from './edit/job-edit.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        JobsRoutingModule
    ],
    declarations: [
        JobListComponent,
        JobCreateComponent,
        JobEditComponent
    ]
})
export class JobsModule { }