import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { JobsService } from '../../../services/jobs.service'
import { Job } from './../../../classes/job'
import { Router } from '@angular/router'


@Component({
  selector: 'job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css'],
  providers: [JobsService]
})
export class JobListComponent implements OnInit {

  errorMessage: string;

  _listOfJobs: Job[];

  id: string = "";

  job: Job = new Job();

  parentRouter;
  @Output() selectedChange: EventEmitter<Job> = new EventEmitter();

  @Output() close = new EventEmitter();
  errors: string[];
  navigated = false; // true if we navigated here

  constructor(private router: Router,
    private jobsService: JobsService) { }


  ngOnInit() {
    this.getJobs();
  }

  // Gets the list of jobs from service
  getJobs() {
    this.jobsService.getJobs().then(jobs => this._listOfJobs = jobs);
  }

  addJob(): void {
    if (!this.job) { return; }
    this.jobsService.create(this.job)
      .then(
      job => {
        this.getJobs();
      },
      error => this.errorMessage = <any>error,
    );
    this.job.name = "";
    this.job.cor = "";
  }

  deleteJob(id: string) {

    this.jobsService.delete(id).subscribe(
      job => {
        this.getJobs();
      },
      error => this.errorMessage = <any>error,
    );
  }

  goToDetail(job: Job): void {
    let link = ['/jobs/edit/', job.id];
    this.router.navigate(link);
  }

}
