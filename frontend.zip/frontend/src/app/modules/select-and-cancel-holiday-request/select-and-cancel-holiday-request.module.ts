import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { HolidayRequestRoutingModule } from './holiday-request-routing.module';

import { HolidayRequestCreateComponent } from './create/holiday-request-create.component';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        
    ],
    declarations: [
        HolidayRequestCreateComponent,
    ]
})
export class HolidayRequestModule { }