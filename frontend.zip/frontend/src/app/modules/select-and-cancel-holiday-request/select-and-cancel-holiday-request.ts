import { HolidayRequestDTO } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/modules/holiday-request/entity-DTO/HolidayRequestDTO';
import { HolidayRequestService } from '/Users/alin/Documents/Matrix/Matrix/frontend/src/app/services/holiday-request.service';
import { ChangeDetectorRef } from '@angular/core';
import { Component } from '@angular/core';

@Component({
  selector: 'select-and-cancel-holiday-request',
  templateUrl: './select-and-cancel-holiday-request.html',
  styleUrls: ['./select-and-cancel-holiday-request.css'],
})

export class CalendarComponent {

    events: any[];
    
    header: any;
    
    event: HolidayRequestDTO;
    
    dialogVisible: boolean = false;
    
    idGen: number = 100;
    
    constructor(private cd: ChangeDetectorRef) { }

handleDayClick(event) {
        this.event = new HolidayRequestDTO();
        this.event.startDate = event.date.format();
        this.dialogVisible = true;
        
        //trigger detection manually as somehow only moving the mouse quickly after click triggers the automatic detection
        this.cd.detectChanges();
    }
    
    handleEventClick(e) {
        this.event = new HolidayRequestDTO();
        this.event.holidayType = e.calEvent.title;
        
        let start = e.calEvent.start;
        let end = e.calEvent.end;
        if(e.view.name === 'month') {
            start.stripTime();
        }
        
        if(end) {
            end.stripTime();
            this.event.endDate = end.format();
        }

        this.event.holidayType = e.calEvent.id;
        this.event.startDate = start.format();
        this.dialogVisible = true;
    }

    deleteEvent() {
        let index: number = this.findEventIndexById(this.event.id);
        if(index >= 0) {
            this.events.splice(index, 1);
        }
        this.dialogVisible = false;
    }

    findEventIndexById(id: String) {
        let index = -1;
        for(let i = 0; i < this.events.length; i++) {
            if(id == this.events[i].id) {
                index = i;
                break;
            }
        }
        
        return index;
    }
}